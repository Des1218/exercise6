<?php
?>
<div class="copyright">
    <p>&copy; BSIT-3D of PAMANTASAN NG LUNGSOD NG MUNTINLUPA. All Rights Reserved.</p>
</div>
